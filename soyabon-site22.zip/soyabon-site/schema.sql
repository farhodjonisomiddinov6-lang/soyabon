-- Soyabon Kafe: Supabase jadvali. Supabase > SQL Editor ichida bir marta ishga tushiring.
create table if not exists public.docs (
  coll text not null,
  id   text not null,
  data jsonb not null,
  updated_at timestamptz not null default now(),
  primary key (coll, id)
);

alter table public.docs enable row level security;

-- DIQQAT: bu NAMUNA (prototip) qoidalari: saytni ochgan har kim o'qiy va yoza oladi.
-- Haqiqiy ishga tushirishdan oldin README.md dagi «Xavfsizlik» bo'limiga qarang.
drop policy if exists "anon read"   on public.docs;
drop policy if exists "anon insert" on public.docs;
drop policy if exists "anon update" on public.docs;
create policy "anon read"   on public.docs for select to anon using (true);
create policy "anon insert" on public.docs for insert to anon with check (coll in ('users','orders','bookings','calls'));
create policy "anon update" on public.docs for update to anon using (true) with check (coll in ('users','orders','bookings','calls'));
