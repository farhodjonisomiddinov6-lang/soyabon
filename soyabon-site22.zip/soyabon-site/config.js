// Supabase sozlamalari (README.md ga qarang)
window.SOYABON_SUPABASE={url:"https://SIZNING-LOYIHA.supabase.co",key:"SIZNING-ANON-KEY"};
