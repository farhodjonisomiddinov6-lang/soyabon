# Soyabon Kafe: haqiqiy internetga chiqarish (Supabase + Netlify)

Hammasi bepul tarifda ishlaydi. Taxminan 20–30 daqiqa.

## 1. Baza (Supabase)
1. https://supabase.com ga kiring, «New project» bosing (nom: soyabon, parol: o'zingiz o'ylab toping, mintaqa: Frankfurt).
2. Loyiha tayyor bo'lgach, chapdagi **SQL Editor** ga kiring. `schema.sql` faylini ochib, ichidagini nusxalab qo'ying va **Run** bosing. «Success» chiqishi kerak.
3. **Project Settings → API** ga kiring. Ikkita narsani nusxalang:
   - **Project URL** (masalan `https://abcd1234.supabase.co`)
   - **anon public** kalit (eyJ... bilan boshlanadi) yoki yangi loyihalarda **Publishable key** (sb_publishable_... bilan boshlanadi). Ikkalasi ham yaraydi.
4. `config.js` faylini oching va ikkala qiymatni joyiga yozing:
   ```js
   window.SOYABON_SUPABASE={url:"https://abcd1234.supabase.co",key:"eyJ..."};
   ```

## 2. Sayt (Netlify)
1. https://app.netlify.com/drop ga kiring.
2. Shu `deploy` papkasini (ichida index.html, config.js bor) sahifaga sudrab tashlang.
3. Netlify sizga manzil beradi (masalan `https://xxxx.netlify.app`). Sayt tayyor. Xohlasangiz, Netlify sozlamalaridan nomini yoki o'z domeningizni qo'yishingiz mumkin.

## 3. Tekshirish
1. Telefonda saytni oching, dastavchi sifatida ariza yuboring.
2. Kompyuterda menejer sifatida kiring (`+998 90 111 00 01`, `menejer2026`). «SMS» jadvalida ariza ko'rinadi.
3. Tasdiqlang, kodni telefonda kiriting, panel ochiladi.
4. Boshqa telefondan mijoz bo'lib buyurtma bering, oshxona va dastavchi panellarida ko'ring.

Pastdagi yozuv «Umumiy server: ulangan» desa, hammasi to'g'ri. «Mahalliy rejim» desa, config.js dagi URL yoki kalit noto'g'ri.

## Xavfsizlik (muhim)
Bu **namuna (prototip)** sozlamasi. Kalit sahifa kodida ochiq turadi, shuning uchun saytni ochgan har kim:
- baza ma'lumotlarini (shu jumladan parollarning zaif shifrini) o'qiy oladi;
- texnik bilimi bo'lsa, o'z arizasini o'zi «tasdiqlab» qo'ya oladi.

Do'stlar va xodimlar bilan sinash uchun yaxshi. Haqiqiy mijozlar va pul uchun yetarli emas. Haqiqiy ishga tushirishdan oldin kerak bo'ladi:
1. Supabase Auth bilan haqiqiy kirish (parollar bazada emas, serverda), telefon orqali SMS (Eskiz/Twilio).
2. Menejer amallari (tasdiqlash, kod berish) faqat serverda, menejer huquqi bilan tekshiriladi.
3. Jadval qoidalarini (RLS) rolga qarab qattiqlashtirish.
4. To'lov (Click/Payme) serverda.

Ana shu bosqichni keyingi qadam sifatida qilib berishim mumkin.

Namuna hisoblar: menejer `+998 90 111 00 01` / `menejer2026`, oshxona `+998 90 111 00 02` / `oshxona2026`. Ishga tushirishdan oldin ularning parollarini almashtiring.
